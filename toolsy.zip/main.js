// ====== Common JS for Toolzy ======

// Display alert if user clicks on disabled feature (optional future features)
function featureComingSoon() {
  alert("🚀 This feature is coming soon!");
}

// Smooth scroll to top (optional)
function scrollToTop() {
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Example: Initialize all tool pages
document.addEventListener('DOMContentLoaded', () => {
  console.log("Toolzy JS loaded successfully ✅");

  // Optional: Highlight current nav link
  const navLinks = document.querySelectorAll('.navbar nav a');
  navLinks.forEach(link => {
    if (link.href === window.location.href) {
      link.classList.add('active');
    }
  });

  // Future shared features placeholder
  // Example: Ads placeholder, analytics, tracking, etc.
});